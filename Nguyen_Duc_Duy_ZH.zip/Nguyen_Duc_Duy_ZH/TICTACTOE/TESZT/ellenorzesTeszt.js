QUnit.module('row', function () {
    QUnit.test('A row függvény létezik e?', function (assert) {
        assert.ok(row, "Létezik a row függvény.");
    });
    QUnit.test('A row függvény-e?', function (assert) {
        assert.ok(typeof row === "function", "A row függvény");
    });
    QUnit.test('eset1', assert => {
        tomb=["X","X","X","O","O","-","-","-","-",]
        assert.equal(row(), true);
    });
    QUnit.test('eset2', assert => {
        tomb=["O","O","O","X","X","-","-","-","-",]
        assert.equal(row(), true);
    });
    QUnit.test('eset3', assert => {
        tomb=["-","-","-","-","O","O","X","X","X",]
        assert.equal(row(), true);
    });
    QUnit.test('eset4', assert => {
        tomb=["-","-","-","-","X","X","O","O","O",]
        assert.equal(row(), true);
    });
    QUnit.test('eset5', assert => {
        tomb=["X","O","X","O","X","-","-","-","-",]
        assert.equal(row(), true);
    });
    QUnit.test('eset6', assert => {
        tomb=["O","X","O","X","O","-","-","-","-",]
        assert.equal(row(), true);
    });
    QUnit.test('eset7', assert => {
        tomb=["-","O","O","X","X","X","-","-","-",]
        assert.equal(row(), true);
    });
    QUnit.test('eset8', assert => {
        tomb=["X","X","X","X","X","X","-","-","-",]
        assert.equal(row(), true);
    });
});

QUnit.module('column', function () {
    QUnit.test('A column függvény létezik e?', function (assert) {
        assert.ok(column, "Létezik a column függvény.");
    });
    QUnit.test('A column függvény-e?', function (assert) {
        assert.ok(typeof column === "function", "A column függvény");
    });
    QUnit.test('eset1', assert => {
        tomb=["X","X","X","O","O","-","-","-","-",]
        assert.equal(column(), true);
    });
    QUnit.test('eset2', assert => {
        tomb=["O","O","O","X","X","-","-","-","-",]
        assert.equal(column(), true);
    });
    QUnit.test('eset3', assert => {
        tomb=["-","-","-","-","O","O","X","X","X",]
        assert.equal(column(), true);
    });
    QUnit.test('eset4', assert => {
        tomb=["-","-","-","-","X","X","O","O","O",]
        assert.equal(column(), true);
    });
    QUnit.test('eset5', assert => {
        tomb=["X","O","X","O","X","-","-","-","-",]
        assert.equal(column(), true);
    });
    QUnit.test('eset6', assert => {
        tomb=["O","X","O","X","O","-","-","-","-",]
        assert.equal(column(), true);
    });
    QUnit.test('eset7', assert => {
        tomb=["-","O","O","X","X","X","-","-","-",]
        assert.equal(column(), true);
    });
    QUnit.test('eset8', assert => {
        tomb=["X","X","X","X","X","X","-","-","-",]
        assert.equal(column(), true);
    });
});

QUnit.module('balrolJobra', function () {
    QUnit.test('A balrolJobra függvény létezik e?', function (assert) {
        assert.ok(balrolJobra, "Létezik a balrolJobra függvény.");
    });
    QUnit.test('A balrolJobra függvény-e?', function (assert) {
        assert.ok(typeof balrolJobra === "function", "A balrolJobra függvény");
    });
    QUnit.test('eset1', assert => {
        tomb=["X","X","X","O","O","-","-","-","-",]
        assert.equal(balrolJobra(), true);
    });
    QUnit.test('eset2', assert => {
        tomb=["O","O","O","X","X","-","-","-","-",]
        assert.equal(balrolJobra(), true);
    });
    QUnit.test('eset3', assert => {
        tomb=["-","-","-","-","O","O","X","X","X",]
        assert.equal(balrolJobra(), true);
    });
    QUnit.test('eset4', assert => {
        tomb=["-","-","-","-","X","X","O","O","O",]
        assert.equal(balrolJobra(), true);
    });
    QUnit.test('eset5', assert => {
        tomb=["X","O","X","O","X","-","-","-","-",]
        assert.equal(balrolJobra(), true);
    });
    QUnit.test('eset6', assert => {
        tomb=["O","X","O","X","O","-","-","-","-",]
        assert.equal(balrolJobra(), true);
    });
    QUnit.test('eset7', assert => {
        tomb=["-","O","O","X","X","X","-","-","-",]
        assert.equal(balrolJobra(), true);
    });
    QUnit.test('eset8', assert => {
        tomb=["X","X","X","X","X","X","-","-","-",]
        assert.equal(balrolJobra(), true);
    });
});

QUnit.module('jobbrolBalra', function () {
    QUnit.test('A jobbrolBalra függvény létezik e?', function (assert) {
        assert.ok(jobbrolBalra, "Létezik a jobbrolBalra függvény.");
    });
    QUnit.test('A row függvény-e?', function (assert) {
        assert.ok(typeof jobbrolBalra === "function", "A jobbrolBalra függvény");
    });
    QUnit.test('eset1', assert => {
        tomb=["X","X","X","O","O","-","-","-","-",]
        assert.equal(jobbrolBalra(), true);
    });
    QUnit.test('eset2', assert => {
        tomb=["O","O","O","X","X","-","-","-","-",]
        assert.equal(jobbrolBalra(), true);
    });
    QUnit.test('eset3', assert => {
        tomb=["-","-","-","-","O","O","X","X","X",]
        assert.equal(jobbrolBalra(), true);
    });
    QUnit.test('eset4', assert => {
        tomb=["-","-","-","-","X","X","O","O","O",]
        assert.equal(jobbrolBalra(), true);
    });
    QUnit.test('eset5', assert => {
        tomb=["X","O","X","O","X","-","-","-","-",]
        assert.equal(jobbrolBalra(), true);
    });
    QUnit.test('eset6', assert => {
        tomb=["O","X","O","X","O","-","-","-","-",]
        assert.equal(jobbrolBalra(), true);
    });
    QUnit.test('eset7', assert => {
        tomb=["-","O","O","X","X","X","-","-","-",]
        assert.equal(jobbrolBalra(), true);
    });
    QUnit.test('eset8', assert => {
        tomb=["X","X","X","X","X","X","-","-","-",]
        assert.equal(jobbrolBalra(), true);
    });
});

QUnit.module('cross', function () {
    QUnit.test('A cross függvény létezik e?', function (assert) {
        assert.ok(cross, "Létezik a cross függvény.");
    });
    QUnit.test('A cross függvény-e?', function (assert) {
        assert.ok(typeof cross === "function", "A cross függvény");
    });
    QUnit.test('eset1', assert => {
        tomb=["X","X","X","O","O","-","-","-","-",]
        assert.equal(cross(), true);
    });
    QUnit.test('eset2', assert => {
        tomb=["O","O","O","X","X","-","-","-","-",]
        assert.equal(cross(), true);
    });
    QUnit.test('eset3', assert => {
        tomb=["-","-","-","-","O","O","X","X","X",]
        assert.equal(cross(), true);
    });
    QUnit.test('eset4', assert => {
        tomb=["-","-","-","-","X","X","O","O","O",]
        assert.equal(cross(), true);
    });
    QUnit.test('eset5', assert => {
        tomb=["X","O","X","O","X","-","-","-","-",]
        assert.equal(cross(), true);
    });
    QUnit.test('eset6', assert => {
        tomb=["O","X","O","X","O","-","-","-","-",]
        assert.equal(cross(), true);
    });
    QUnit.test('eset7', assert => {
        tomb=["-","O","O","X","X","X","-","-","-",]
        assert.equal(cross(), true);
    });
    QUnit.test('eset8', assert => {
        tomb=["X","X","X","X","X","X","-","-","-",]
        assert.equal(cross(), true);
    });
    QUnit.test('vanEgyoztes egyenlő-e balrolJobra-val?', assert => {
        assert.equal(cross(vanEGyoztes), balrolJobra());
    });
    QUnit.test('vanEgyoztes egyenlő-e jobbrolBalra-val?', assert => {
        assert.equal(cross(vanEGyoztes), jobbrolBalra());
    });
});

QUnit.module('ellenorzes', function () {
    QUnit.test('Az ellenorzes függvény létezik e?', function (assert) {
        assert.ok(ellenorzes, "Létezik az ellenorzes függvény.");
    });
    QUnit.test('A cross ellenorzes-e?', function (assert) {
        assert.ok(typeof ellenorzes === "function", "A ellenorzes függvény");
    });
    QUnit.test('A cross függvény-e?', function (assert) {
        assert.ok(typeof cross === "function", "A cross függvény");
    });
    QUnit.test('eset1', assert => {
        tomb=["X","X","X","O","O","-","-","-","-",]
        assert.equal(ellenorzes(), true);
    });
    QUnit.test('eset2', assert => {
        tomb=["O","O","O","X","X","-","-","-","-",]
        assert.equal(ellenorzes(), true);
    });
    QUnit.test('eset3', assert => {
        tomb=["-","-","-","-","O","O","X","X","X",]
        assert.equal(ellenorzes(), true);
    });
    QUnit.test('eset4', assert => {
        tomb=["-","-","-","-","X","X","O","O","O",]
        assert.equal(ellenorzes(), true);
    });
    QUnit.test('eset5', assert => {
        tomb=["X","O","X","O","X","-","-","-","-",]
        assert.equal(ellenorzes(), true);
    });
    QUnit.test('eset6', assert => {
        tomb=["O","X","O","X","O","-","-","-","-",]
        assert.equal(ellenorzes(), true);
    });
    QUnit.test('eset7', assert => {
        tomb=["-","O","O","X","X","X","-","-","-",]
        assert.equal(ellenorzes(), true);
    });
    QUnit.test('eset8', assert => {
        tomb=["X","X","X","X","X","X","-","-","-",]
        assert.equal(ellenorzes(), true);
    });
    QUnit.test('vanEgyoztes', assert => {
        assert.equal(ellenorzes(!vanEGyoztes), false);
    });
    QUnit.test('vanEgyoztes', assert => {
        assert.equal(ellenorzes(!vanEGyoztes), false);
    });
    QUnit.test('vanEgyoztes egyenlő-e row-al?', assert => {
        assert.equal(ellenorzes(vanEGyoztes), row());
    });
});

